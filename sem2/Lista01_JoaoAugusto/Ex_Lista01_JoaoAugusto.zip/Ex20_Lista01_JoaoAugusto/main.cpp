#include <cstdlib>
#include "cProduto.h"

using namespace std;

int main(int argc, char** argv) {
    cProduto obj;
    
    obj.insert();
    obj.print();
    
    return 0;
}

