#include <cstdlib>
#include "cIdade.h"

using namespace std;

int main(int argc, char** argv) {
    cIdade obj;
    
    obj.insert();
    obj.print();

    return 0;
}

