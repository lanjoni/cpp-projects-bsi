#include <cstdlib>
#include "cDuracao.h"

using namespace std;

int main(int argc, char** argv) {
    cDuracao obj;
    
    obj.insert();
    obj.print();
    
    return 0;
}

