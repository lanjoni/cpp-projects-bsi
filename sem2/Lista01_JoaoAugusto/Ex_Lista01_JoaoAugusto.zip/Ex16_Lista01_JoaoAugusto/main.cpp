#include <cstdlib>
#include "cLanche.h"

using namespace std;

int main(int argc, char** argv) {
    cLanche obj;
    
    obj.insert();
    obj.print();
    
    return 0;
}

