#include <cstdlib>
#include "cCalculo.h"

using namespace std;

int main(int argc, char** argv) {
    cCalculo obj;
    
    obj.insert();
    obj.print();

    return 0;
}

