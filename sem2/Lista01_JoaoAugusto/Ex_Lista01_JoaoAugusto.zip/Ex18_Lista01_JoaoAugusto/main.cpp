#include <cstdlib>
#include "cSaldo.h"

using namespace std;

int main(int argc, char** argv) {
    cSaldo obj;
    
    obj.insert();
    obj.print();
    
    return 0;
}

