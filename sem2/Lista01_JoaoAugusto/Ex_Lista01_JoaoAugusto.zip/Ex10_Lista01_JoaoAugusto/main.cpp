#include <cstdlib>
#include "cMaior.h"

using namespace std;

int main(int argc, char** argv) {
    cMaior obj;
    
    obj.insert();
    obj.print();
    
    return 0;
}

