#include <cstdlib>
#include "cCarro.h"

using namespace std;

int main(int argc, char** argv) {
    cCarro obj;
    
    obj.insert();
    obj.print();
    
    return 0;
}