#include <cstdlib>
#include "cPeso.h"

using namespace std;

int main(int argc, char** argv) {
    cPeso obj;
    
    obj.insert();
    obj.print();
    
    return 0;
}

