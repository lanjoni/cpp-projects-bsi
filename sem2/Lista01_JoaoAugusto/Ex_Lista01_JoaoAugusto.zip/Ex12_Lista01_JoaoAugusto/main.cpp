#include <cstdlib>
#include "cNadador.h"

using namespace std;

int main(int argc, char** argv) {
    cNadador obj;
    
    obj.insert();
    obj.print();
    
    return 0;
}

