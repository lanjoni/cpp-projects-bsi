#include <cstdlib>
#include "cNota.h"

using namespace std;

int main(int argc, char** argv) {
    cNota obj;
    
    obj.insert();
    obj.print();
    
    return 0;
}

