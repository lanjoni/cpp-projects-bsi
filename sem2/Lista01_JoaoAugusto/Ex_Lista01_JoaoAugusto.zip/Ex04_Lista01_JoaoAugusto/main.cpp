#include <cstdlib>
#include "cIdadeAoContrario.h"

using namespace std;

int main(int argc, char** argv) {
    cIdadeAoContrario obj;
    
    obj.insert();
    obj.print();

    return 0;
}

