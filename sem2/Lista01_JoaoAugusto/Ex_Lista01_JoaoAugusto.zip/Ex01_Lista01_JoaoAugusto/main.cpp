#include <cstdlib>
#include "cDistancia.h"

using namespace std;

int main(int argc, char** argv) {
    cDistancia obj;
    
    obj.insert();
    
    return 0;
}

